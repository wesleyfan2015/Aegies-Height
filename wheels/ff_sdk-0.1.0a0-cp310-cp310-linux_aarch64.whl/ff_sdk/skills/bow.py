"""ff_sdk.skills.bow — bow/nod across all robot platforms.

Implementations:
  - Navi (a100_dev): do_action(20510 = bow) via navi namespace
  - A2:    motion.do_preset("bow") if available, else "nod"
  - X2:    motion.do_preset_oem(motion_id=3001, area=11) — TODO 真 bow ID
  - D1:    motion.do_preset("nod") fallback
  - Mujoco: lie_down 1s (visual placeholder)
"""
from __future__ import annotations

import logging

from ff_sdk.core.exceptions import CapabilityNotSupported

log = logging.getLogger(__name__)


__skill_meta__ = {
    "name": "bow",
    "version": "0.1.0",
    "author": "ff_sdk_core",
    "author_pubkey": None,
    "signature": None,
    "requires_capabilities": ["motion"],
    "requires_platforms": ["a2", "x2", "d1", "navi", "mujoco"],
    "permission": "low_risk",
    "description": "Bow / nod gesture across robots",
}


async def bow(session, *, depth: float = 1.0) -> dict:
    """Bow / nod across robots.

    Args:
        session: ff_sdk.Session
        depth: 0.0-1.0 (most platforms ignore this currently)

    Returns:
        dict {ok, message, platform}
    """
    platform = session.adapter.platform_name

    if platform == "navi":
        navi = session.adapter.navi
        if navi is None:
            raise CapabilityNotSupported("bow requires session.navi (a100_dev)")
        try:
            actions = await navi.list_actions()
            action_id = actions.by_name("bow") or 20510
        except Exception:  # noqa: BLE001
            action_id = 20510
        result = await navi.do_action(action_id, hold_time=3.0)
        return {"ok": True, "message": f"navi bow → {result}", "platform": "navi"}

    if platform == "a2":
        if session.motion is None:
            raise CapabilityNotSupported("a2 motion not available")
        # A2 has "nod" but not "bow" in current preset list (TODO 加 bow preset)
        for preset in ("bow", "nod"):
            try:
                result = await session.motion.do_preset(preset)
                return {
                    "ok": getattr(result, "success", False),
                    "message": f"a2 do_preset({preset}) → {result}",
                    "platform": "a2",
                }
            except CapabilityNotSupported:
                continue
        raise CapabilityNotSupported("a2 has neither bow nor nod preset")

    if platform == "x2":
        if session.motion is None or not hasattr(session.motion, "do_preset_oem"):
            raise CapabilityNotSupported("x2 motion.do_preset_oem not available")
        # X2 bow motion_id 待逆向 (3001=salute, 实际 bow id 未确认)
        # TODO 反编译 AGIBOT Go app 找 bow 真 id, 当前用 3005=bow per memory
        result = await session.motion.do_preset_oem(motion_id=3005, area=11)
        return {
            "ok": getattr(result, "success", False),
            "message": f"x2 do_preset_oem(3005=bow, 11) → {result}",
            "platform": "x2",
        }

    if platform == "d1":
        if session.motion is None:
            raise CapabilityNotSupported("d1 motion not available")
        try:
            result = await session.motion.do_preset("nod")
            return {
                "ok": getattr(result, "success", False),
                "message": f"d1 nod (no bow) → {result}",
                "platform": "d1",
            }
        except CapabilityNotSupported:
            raise CapabilityNotSupported("d1 has no bow/nod preset")

    if platform == "mujoco":
        if session.motion is None:
            raise CapabilityNotSupported("mujoco motion not available")
        result = await session.motion.do_preset("lie_down")
        return {
            "ok": True,
            "message": f"mujoco bow (lie_down placeholder) → {result}",
            "platform": "mujoco",
        }

    raise CapabilityNotSupported(f"bow not implemented for platform={platform!r}")
