"""DisplayCapability — robot face / expression / status light.

**In scope for Phase 1.5**:
- show_expression(preset_id) — play a built-in face animation
- show_text(text) — render text on face screen (optional)
- set_led(color, pattern) — RGB status lights

**Out of scope**:
- Generic Flutter UI rendering — A2 AimMaster Flutter app has a separate path
  (DRM) that typically fights fb0; see memory `a2_new_face_display_architecture`
- Custom MP4 upload — fully platform specific, use raw_* if needed
"""
from __future__ import annotations

import abc

from ff_sdk.capabilities.base import Capability


class DisplayCapability(Capability):
    """Robot visual output: face expression, text, status LEDs."""

    name = "display"

    @abc.abstractmethod
    async def show_expression(self, preset: str) -> None:
        """Play a built-in face expression by name.

        Valid names depend on the platform — A2 has 28 emoticons (happy /
        thinking / listening / welcome / normal ...). Use
        list_expressions() to enumerate.

        Raises CapabilityNotSupported if the name is unknown.
        """

    @abc.abstractmethod
    async def list_expressions(self) -> tuple[str, ...]:
        """Return tuple of supported preset names on this platform."""

    @abc.abstractmethod
    async def show_text(self, text: str) -> None:
        """Render text on face screen. Platforms without text support should
        raise CapabilityNotSupported rather than silent-fallback."""

    @abc.abstractmethod
    async def set_led(
        self, *, color: str = "off", pattern: str = "solid"
    ) -> None:
        """Set status LED. color: 'off' | 'red' | 'green' | 'blue' | 'white' |
        '#RRGGBB'. pattern: 'solid' | 'blink' | 'pulse'."""
