"""ArmCapability — humanoid arm / manipulator control.

**In scope**: joint-space arm pose, TCP pose query, gripper open/close,
              joint-level streaming (path A 自研运控).
**Out of scope**: trajectory planning / IK solving (use ROS2 MoveIt separately),
force control, compliance.

Adapters:
- A2: aimrt `McArmService` + ROS 2 `/motion/control/arm_joint_command`,
      + `joint_servo_stream()` via motion_streamer bridge (see
      `services/a2_motion_research/motion_streamer_bridge/`)
- D1: ❌ 四足，无臂
- X2: ❌ v0.9.6 未暴露单臂 API
"""
from __future__ import annotations

import abc
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass, field
from typing import Any

from ff_sdk.capabilities.base import Capability


@dataclass(frozen=True)
class ArmJointAngles:
    """Joint angles (rad) for one arm. Typical order: 7-DOF, shoulder→wrist."""
    angles: tuple[float, ...] = field(default_factory=tuple)
    arm: str = "right"  # "left" | "right" | "both" (if both, 14 values)


@dataclass(frozen=True)
class TcpPose:
    """End-effector (TCP) pose in robot base frame. Meters / rad (ZYX Euler)."""
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    roll: float = 0.0
    pitch: float = 0.0
    yaw: float = 0.0
    arm: str = "right"


class ArmCapability(Capability):
    """Dual/single arm control primitives."""

    name = "arm"

    @abc.abstractmethod
    async def pose_arm(
        self, joints: ArmJointAngles, *, duration_s: float = 2.0
    ) -> bool:
        """Move arm to `joints` over `duration_s`. Returns True on completion."""

    @abc.abstractmethod
    async def current_tcp(self, arm: str = "right") -> TcpPose:
        """Read current TCP pose."""

    @abc.abstractmethod
    async def grasp(self, arm: str = "right") -> bool:
        """Close gripper. Returns True when gripped (force threshold met)."""

    @abc.abstractmethod
    async def release(self, arm: str = "right") -> bool:
        """Open gripper."""

    # ----------------------------------------------------------------- joint streaming
    async def joint_servo_stream(
        self,
        angles_func: Callable[[float], tuple[list[float], list[float]]],
        *,
        rate_hz: float = 60.0,
        duration_s: float | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """Stream both-arm joint angles (14 维) at `rate_hz`.

        Args:
            angles_func: t -> (left_7, right_7) rad
            rate_hz: 60 Hz typical (matches motion_streamer 60 Hz baseline)
            duration_s: total run time

        Yields:
            `{"t": float, "left_cmd": [7], "right_cmd": [7],
              "left_meas": [7] | None, "right_meas": [7] | None}`

        Notes:
            A2 实现走 `services/a2_motion_research/motion_streamer_bridge/`
            P2 旁路 — publish `/aimrt_adapter/vr_data` ROS2 msg。
            前置：A2 同机 `motion_streamer` 已启 + mc 在
            `RL_LOCOMOTION_ARM_EXT_JOINT_SERVO` 模式。
        """
        # Default: optional capability, adapter must override when supported.
        # Mirrors the pattern in motion.joint_stream (a2_motion_research Path A).
        from ff_sdk.core.exceptions import CapabilityNotSupported

        raise CapabilityNotSupported(
            f"joint_servo_stream not provided by {self._adapter.platform_name} arm"
        )
        yield  # unreachable — keeps this an async generator

    async def read_arm_state(self) -> dict[str, list[float]]:
        """Read arm joint state (rad).

        Returns: `{"left": [7], "right": [7], "joint_names": [14]}`
        A2 实现走 ROS2 `/motion/control/arm_joint_state` (sensor_msgs/JointState)。
        """
        from ff_sdk.core.exceptions import CapabilityNotSupported

        raise CapabilityNotSupported(
            f"read_arm_state not provided by {self._adapter.platform_name} arm"
        )
