"""CheckinCapability — face-based check-in / attendance system.

**In scope**: enroll new face, recognize current frame, list registered faces,
enable/disable auto-greeting。

**Out of scope**: the face engine itself（ArcFace + RetinaFace ONNX/TRT）—
那是后端服务（H200 face_engine 或 Orin Nano 本地镜像）。ff_sdk 只封装
REST 客户端 + 把机器人相机帧送上去。

Adapters:
- A2: `camera_watcher` + H200 `face_engine` REST
- D1: 同上（memory `a2_d1_centralized_face_db`）
- X2: 未做（X2 无 camera_watcher 对等服务）
"""
from __future__ import annotations

import abc
from dataclasses import dataclass


@dataclass(frozen=True)
class RecognitionResult:
    name: str | None        # None = 未识别
    score: float = 0.0      # 0.0–1.0 余弦相似度
    bbox: tuple[int, int, int, int] | None = None  # (x1,y1,x2,y2) 像素


@dataclass(frozen=True)
class EnrollResult:
    ok: bool
    message: str = ""
    job_id: str | None = None    # 实时 enroll 返 job_id，异步查进度


from ff_sdk.capabilities.base import Capability  # noqa: E402  保持 dataclass 在前面


class CheckinCapability(Capability):
    """Face recognition + check-in 表面。"""

    name = "checkin"

    @abc.abstractmethod
    async def enroll(self, name: str, *, employee_id: str = "",
                     department: str = "") -> EnrollResult:
        """启动为名字 `name` 的人脸录入任务（机器人用本地相机采多帧）。
        返回 EnrollResult（含 job_id）后，调用方可 poll `enroll_status(job_id)`。"""

    @abc.abstractmethod
    async def enroll_status(self, job_id: str) -> dict:
        """Query enroll job 进度。返回 {running, progress, error, ...}。"""

    @abc.abstractmethod
    async def recognize(self, jpg: bytes) -> RecognitionResult:
        """给一张 JPEG 送去识别。返回 RecognitionResult。"""

    @abc.abstractmethod
    async def list_faces(self) -> tuple[str, ...]:
        """已注册人脸名字列表。"""

    @abc.abstractmethod
    async def set_auto_greet(self, enabled: bool) -> None:
        """开关识别到人时自动说欢迎词 + 表情。"""
