"""NavigationCapability — map-based goto / waypoint navigation.

**In scope**: issue goal pose → robot plans + drives there asynchronously;
waypoint list管理；current waypoint 查询。

**Out of scope in ff_sdk**:
- Building the map itself（跑 SLAM）
- Re-localization / pose graph 维护
- Policy/behavior planners

Adapters typically back this by:
- A2: ROS 2 Nav2 `NavigateToPose` action
- D1: `d1_services/patrol*` 的 multi_nav / start_ref_nav UDP 命令
- X2: 暂无（v0.9.6 无 SLAM）
"""
from __future__ import annotations

import abc

from ff_sdk.capabilities.base import Capability
from ff_sdk.capabilities.types import Pose


class NavigationCapability(Capability):
    """Map-based navigation. `CapabilityNotSupported` on platforms without SLAM."""

    name = "navigation"

    @abc.abstractmethod
    async def goto(self, pose: Pose, *, timeout_s: float | None = None) -> bool:
        """Navigate to world-frame pose. Blocks until arrival or timeout.
        Returns True if arrived within tolerance, False if cancelled/timed out.
        Raises CapabilityNotSupported if SLAM / map is unavailable."""

    @abc.abstractmethod
    async def cancel(self) -> None:
        """Cancel currently-running goto."""

    @abc.abstractmethod
    async def list_waypoints(self) -> tuple[str, ...]:
        """Named waypoints available on the platform (from map config)."""

    @abc.abstractmethod
    async def current_waypoint(self) -> str | None:
        """Nearest named waypoint to current pose, or None if not near any."""
