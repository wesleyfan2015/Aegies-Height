"""Capability — base class for all platform-agnostic primitive interfaces."""
from __future__ import annotations

import abc
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ff_sdk.platforms.base import PlatformAdapter


class Capability(abc.ABC):
    """Base for all Capability interfaces (motion, state, vision, audio, ...).

    Concrete implementations live next to their Platform adapter
    (e.g. A2Motion in platforms/a2.py). They hold a reference to the adapter
    so they can reach the underlying OEM client / transport.
    """

    name: str = "capability"

    def __init__(self, adapter: "PlatformAdapter") -> None:
        self._adapter = adapter

    @property
    def adapter(self) -> "PlatformAdapter":
        return self._adapter
