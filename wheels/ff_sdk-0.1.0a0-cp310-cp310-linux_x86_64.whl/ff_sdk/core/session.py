"""Session — a live connection to one robot.

Holds: target identifier, platform adapter, identity, config, e_stop controller,
and lifecycle state. Does not implement any capability itself — adapters do.
"""
from __future__ import annotations

import enum
import logging
import time
from typing import TYPE_CHECKING

from ff_sdk.core.config import Config
from ff_sdk.core.estop import EStop, EStopEvent
from ff_sdk.core.exceptions import EStopActiveError, StateError
from ff_sdk.core.identity import Identity

if TYPE_CHECKING:
    from ff_sdk.capabilities.arm import ArmCapability
    from ff_sdk.capabilities.audio import AudioCapability
    from ff_sdk.capabilities.checkin import CheckinCapability
    from ff_sdk.capabilities.display import DisplayCapability
    from ff_sdk.capabilities.navigation import NavigationCapability
    from ff_sdk.capabilities.motion import MotionCapability
    from ff_sdk.capabilities.state import StateCapability
    from ff_sdk.capabilities.vision import VisionCapability
    from ff_sdk.platforms.base import DiagnosticReport, PlatformAdapter

from ff_sdk.core.exceptions import CapabilityNotSupported

log = logging.getLogger(__name__)


class SessionState(enum.Enum):
    IDLE = "idle"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    DEGRADED = "degraded"
    ESTOPPED = "estopped"
    DISCONNECTED = "disconnected"
    FAULT = "fault"


class Session:
    """One open connection to a robot.

    Usage:
        session = await ff.connect("A2-0657")
        try:
            await session.e_stop(reason="test")
            report = session.diagnose()
        finally:
            await session.close()
    """

    def __init__(self, *, target: str, adapter: "PlatformAdapter",
                 config: Config, identity: Identity) -> None:
        self.target = target
        self.adapter = adapter
        self.config = config
        self.identity = identity
        self.estop = EStop()
        self._state = SessionState.IDLE
        self._opened_at: float | None = None
        self._closed_at: float | None = None

        # When e_stop fires, flag session state. Platform adapters also hook
        # in their own cancel handlers via adapter.bind_estop(self.estop).
        self.estop.register(self._on_estop)

    @property
    def session_state(self) -> SessionState:
        """Lifecycle state (connecting / connected / estopped / ...).

        Renamed from `state` in Phase 1.5 to avoid collision with the
        Capability accessor `session.state` (StateCapability)."""
        return self._state

    @property
    def uptime(self) -> float:
        if self._opened_at is None:
            return 0.0
        end = self._closed_at or time.time()
        return end - self._opened_at

    async def open(self) -> None:
        if self._state is SessionState.CONNECTED:
            return
        if self._state not in (SessionState.IDLE, SessionState.DISCONNECTED):
            raise StateError(f"cannot open from state {self._state.value}")
        self._state = SessionState.CONNECTING
        try:
            await self.adapter.bind(session=self)
            await self.adapter.connect(self.target)
            self._state = SessionState.CONNECTED
            self._opened_at = time.time()
            log.info("session opened: target=%s platform=%s", self.target,
                     self.adapter.platform_name)
        except Exception:
            self._state = SessionState.FAULT
            raise

    async def close(self) -> None:
        if self._state is SessionState.DISCONNECTED:
            return
        try:
            await self.adapter.disconnect()
        finally:
            self._state = SessionState.DISCONNECTED
            self._closed_at = time.time()
            log.info("session closed: target=%s uptime=%.1fs", self.target, self.uptime)

    async def e_stop(self, reason: str = "manual", source: str = "user") -> None:
        """Fire e_stop. Always allowed, regardless of session state."""
        await self.estop.trigger(reason=reason, source=source)
        # Platform adapter must implement fast-path hardware stop.
        await self.adapter.e_stop(reason=reason)

    def diagnose(self) -> "DiagnosticReport":
        """Synchronous health snapshot. Safe to call in any state."""
        return self.adapter.diagnose()

    def capabilities(self) -> set[str]:
        """Names of Capability interfaces this platform implements."""
        return self.adapter.capabilities()

    # --- Capability accessors ----------------------------------------

    @property
    def motion(self) -> "MotionCapability":
        cap = self.adapter.motion
        if cap is None:
            raise CapabilityNotSupported(
                f"motion not available on {self.adapter.platform_name}"
            )
        return cap

    @property
    def state(self) -> "StateCapability":
        cap = self.adapter.state
        if cap is None:
            raise CapabilityNotSupported(
                f"state not available on {self.adapter.platform_name}"
            )
        return cap

    @property
    def vision(self) -> "VisionCapability":
        cap = self.adapter.vision
        if cap is None:
            raise CapabilityNotSupported(
                f"vision not available on {self.adapter.platform_name}"
            )
        return cap

    @property
    def audio(self) -> "AudioCapability":
        cap = self.adapter.audio
        if cap is None:
            raise CapabilityNotSupported(
                f"audio not available on {self.adapter.platform_name}"
            )
        return cap

    @property
    def display(self) -> "DisplayCapability":
        cap = getattr(self.adapter, "display", None)
        if cap is None:
            raise CapabilityNotSupported(
                f"display not available on {self.adapter.platform_name}"
            )
        return cap

    @property
    def navigation(self) -> "NavigationCapability":
        cap = getattr(self.adapter, "navigation", None)
        if cap is None:
            raise CapabilityNotSupported(
                f"navigation not available on {self.adapter.platform_name}"
            )
        return cap

    @property
    def arm(self) -> "ArmCapability":
        cap = getattr(self.adapter, "arm", None)
        if cap is None:
            raise CapabilityNotSupported(
                f"arm not available on {self.adapter.platform_name}"
            )
        return cap

    @property
    def checkin(self) -> "CheckinCapability":
        cap = getattr(self.adapter, "checkin", None)
        if cap is None:
            raise CapabilityNotSupported(
                f"checkin not available on {self.adapter.platform_name}"
            )
        return cap

    async def _on_estop(self, event: EStopEvent) -> None:
        if self._state is SessionState.CONNECTED:
            self._state = SessionState.ESTOPPED
            log.warning("session %s → ESTOPPED (source=%s)", self.target, event.source)

    def assert_operable(self) -> None:
        """Raise if the session can't accept operational commands."""
        if self.estop.is_active:
            raise EStopActiveError(f"e_stop active: {self.estop.last_event}")
        if self._state not in (SessionState.CONNECTED, SessionState.DEGRADED):
            raise StateError(f"session not operable: {self._state.value}")

    async def __aenter__(self) -> Session:
        if self._state is SessionState.IDLE:
            await self.open()
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.close()
