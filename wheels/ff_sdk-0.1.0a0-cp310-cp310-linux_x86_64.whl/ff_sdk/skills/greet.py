"""ff_sdk.skills.greet — combo greeting: wave + optional TTS.

This skill demonstrates **skill composition** — it calls `wave` (another
skill) plus `session.audio.say` (if audio capability is live on this
platform).

If the platform lacks audio, the skill still succeeds (wave-only).
"""
from __future__ import annotations

import logging

from ff_sdk.skills.wave import wave

log = logging.getLogger(__name__)


__skill_meta__ = {
    "name": "greet",
    "version": "0.1.0",
    "author": "ff_sdk_core",
    "author_pubkey": None,
    "signature": None,
    "requires_capabilities": ["motion"],   # audio is optional
    "requires_platforms": ["a2", "x2", "d1", "navi", "mujoco"],
    "permission": "low_risk",
    "description": "Greet someone — wave + say hello (if audio available)",
}


async def greet(session, name: str = "friend", *, language: str = "en") -> dict:
    """Greet someone by name. Wave + speak if audio is available.

    Args:
        session: ff_sdk.Session
        name: who to greet (e.g. "Chen", "Winston")
        language: "en" or "zh"

    Returns:
        dict {ok, message, platform, did_wave, did_say}
    """
    platform = session.adapter.platform_name

    # 1. Wave (always)
    wave_result = await wave(session)
    did_wave = wave_result.get("ok", False)

    # 2. Speak (if audio available)
    # NOTE: session.audio property may raise CapabilityNotSupported on
    # platforms without audio (e.g. Navi). Try/except is the contract.
    did_say = False
    say_msg = ""
    try:
        audio = session.audio
    except Exception:  # noqa: BLE001 — CapabilityNotSupported
        audio = None

    if audio is not None:
        try:
            text = f"你好, {name}!" if language == "zh" else f"Hello, {name}!"
            await audio.say(text)
            did_say = True
            say_msg = f' + said "{text}"'
        except Exception as e:  # noqa: BLE001
            log.warning("greet: audio.say failed (%s); wave-only", e)

    return {
        "ok": did_wave,
        "message": f"{platform} greet({name}) → wave={did_wave}{say_msg}",
        "platform": platform,
        "did_wave": did_wave,
        "did_say": did_say,
    }
