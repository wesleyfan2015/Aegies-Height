"""ff_sdk.skills — cross-platform composite behaviors (L4).

Skills 是 PLAN.md §5.4 定义的 L4 抽象: **用 Capability 原语搭组合行为,
平台无关但能力依赖**. 一个 Skill 在不同机器人 (A2/X2/D1/Navi) 内部
用不同 Capability/Platform-specific 实现, 调用方 1 行代码跨机器人复用.

Two flavors:
  1. FF-internal Skills (this package) — wave/bow/greet ship with ff_sdk
  2. Third-party Skills (Phase 5+) — developers/customers register via
     @register decorator; loaded from ~/.ff_sdk/skills/ at runtime with
     signature verification + permission gate.

Both flavors share the same call surface:
    await ff_sdk.skills.<name>(session, *args, **kwargs)

This v0.5 first-release ships 3 skills as proof-of-concept:
  - wave   — wave a hand/paw across any robot
  - bow    — bow / nod across any robot
  - greet  — combo: wave + (audio.say if available)

Skill metadata convention (`__skill_meta__` at module top) is forward-
compatible with Phase 5 signed-skill loader; today the loader is noop.
"""
from __future__ import annotations

from ff_sdk.skills.wave import wave
from ff_sdk.skills.bow import bow
from ff_sdk.skills.greet import greet

__all__ = ["wave", "bow", "greet"]
