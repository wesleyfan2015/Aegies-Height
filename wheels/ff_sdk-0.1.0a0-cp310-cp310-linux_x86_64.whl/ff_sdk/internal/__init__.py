"""Internal implementation details. Not part of the public API.

Anything under ff_sdk.internal is subject to change without notice and
MUST NOT be imported by user code. OEM SDK adapters and environment
discovery live here.
"""
