"""Per-platform runtime environment detection and injection.

Replaces the hand-written `source setup_a2_env.sh`-style incantations
that each service used to do. Discovery happens at import time so failures
are explicit.
"""
from ff_sdk.internal.env.a2_env import A2Environment, detect_a2_env

__all__ = ["A2Environment", "detect_a2_env"]
