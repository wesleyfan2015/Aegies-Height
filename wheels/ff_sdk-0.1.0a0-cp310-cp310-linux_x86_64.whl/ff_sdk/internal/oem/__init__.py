"""OEM-specific implementation details.

This package holds:
    - aimrt/           — aimrt_py client wrappers (A2, X2), Phase 1.5+
    - aima_ros2/       — aima_protocol_ros2_package bindings, Phase 1.5+
    - dog_task/        — D1 UDP protocol (we wrote this, no OEM SDK exists)
    - ecal_mc_sdk/     — D1 eCAL+mc_sdk_msg bindings, Phase 2+

**Rule**: nothing under ff_sdk.internal.oem may be imported from outside
ff_sdk.platforms.*. Public API types never reference these modules.
"""
