"""Abstract Transport base. Platforms pick and compose these."""
from __future__ import annotations

import abc
import enum
import logging
from typing import Any

from ff_sdk.core.estop import EStop

log = logging.getLogger(__name__)


class TransportState(enum.Enum):
    CLOSED = "closed"
    OPENING = "opening"
    OPEN = "open"
    ERROR = "error"


class Transport(abc.ABC):
    """Base class for all wire-level transports.

    Concrete subclasses: UdpTransport, Ros2Transport, AimrtTransport,
    HttpTransport, WsTransport, SshTransport, EcalTransport, FoxgloveTransport.

    Phase 1 only ships UdpTransport; others land with their owning platform.
    """

    name: str = "transport"

    def __init__(self) -> None:
        self._state: TransportState = TransportState.CLOSED
        self._estop: EStop | None = None

    @property
    def state(self) -> TransportState:
        return self._state

    def bind_estop(self, estop: EStop) -> None:
        """Register with the session's e_stop so the transport can cancel
        in-flight operations when emergency stop fires."""
        self._estop = estop
        estop.register(self._on_estop)

    async def _on_estop(self, event: Any) -> None:
        """Default: no-op. UDP doesn't carry long-running streams; other
        transports (WS, aimrt streaming) should override to cancel tasks."""

    @abc.abstractmethod
    async def open(self) -> None: ...

    @abc.abstractmethod
    async def close(self) -> None: ...

    @abc.abstractmethod
    async def is_alive(self) -> bool: ...
