"""RemoteAdapter — talk to a real robot via `ff_hostd` over HTTP.

The whole point: a developer machine that has **no** ROS / aimrt / rclpy
installed can still `ff.connect("ff-host://10.x.x.x:8090")` and drive a
real A2 (or future X2 / D1) through `ff_hostd`.

Wire format mirrors `ff_hostd/routers/a2.py`. Error codes round-trip:

    HTTP 423  → EStopActiveError | StateError
    HTTP 400  → CapabilityNotSupported
    HTTP 501  → NotImplementedError
    HTTP 502  → ConnectionError

No third-party HTTP library — stdlib urllib + asyncio.to_thread, same
pattern as internal/oem/http/video_bridge.py. Keeps the dev-machine
install footprint tiny.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from ff_sdk.capabilities.audio import AudioCapability
from ff_sdk.capabilities.display import DisplayCapability
from ff_sdk.capabilities.motion import MotionCapability
from ff_sdk.capabilities.state import StateCapability
from ff_sdk.capabilities.types import (
    BatteryState,
    CameraFrame,
    JointStates,
    MotionResult,
    Pose,
    RobotStatus,
)
from ff_sdk.capabilities.vision import VisionCapability
from ff_sdk.core.exceptions import (
    CapabilityNotSupported,
    ConnectionError as FfConnectionError,
    EStopActiveError,
    StateError,
)
from ff_sdk.platforms.base import (
    DiagnosticCheck,
    DiagnosticReport,
    HealthStatus,
    PlatformAdapter,
)

log = logging.getLogger(__name__)

REMOTE_SCHEME = "ff-host"
DEFAULT_TIMEOUT = 6.0
TTS_TIMEOUT = 30.0


# ─── HTTP plumbing ──────────────────────────────────────────────────────


def _raise_from_http(status: int, body: bytes, *, url: str) -> None:
    """Translate ff_hostd's HTTP code contract back into ff_sdk exceptions.

    ff_hostd serializes ff_sdk exceptions as {"error": "<ClassName>",
    "detail": "<message>"}. We re-raise the matching exception so callers
    catch the same ff_sdk types they would for a local A2Adapter.
    """
    try:
        payload = json.loads(body.decode("utf-8", errors="replace"))
    except Exception:
        payload = {"error": "Http", "detail": body[:200].decode(errors="replace")}
    err = str(payload.get("error", ""))
    detail = str(payload.get("detail", f"{url} -> {status}"))

    if status == 423:
        # ff_hostd handles both EStopActiveError and StateError with 423.
        # Use the embedded class name to pick the right one.
        if err == "StateError":
            raise StateError(detail)
        raise EStopActiveError(detail)
    if status == 400:
        raise CapabilityNotSupported(detail)
    if status == 501:
        raise NotImplementedError(detail)
    if status == 502:
        raise FfConnectionError(detail)
    # Anything else: surface as ConnectionError so the developer doesn't
    # silently see a vanilla HTTPError they can't catch with ff_sdk types.
    raise FfConnectionError(f"{url}: HTTP {status} ({err}): {detail}")


def _http_call(
    method: str,
    url: str,
    *,
    json_body: dict[str, Any] | None = None,
    timeout: float = DEFAULT_TIMEOUT,
    token: str | None = None,
) -> tuple[int, bytes, dict[str, str]]:
    """Blocking HTTP call. Caller wraps in asyncio.to_thread for async.

    Token defaults to env `FF_HOSTD_TOKEN` when caller doesn't pass one.
    """
    data = json.dumps(json_body).encode() if json_body is not None else None
    headers: dict[str, str] = (
        {"Content-Type": "application/json"} if data is not None else {}
    )
    effective_token = token if token is not None else (os.environ.get("FF_HOSTD_TOKEN") or None)
    if effective_token:
        headers["Authorization"] = f"Bearer {effective_token}"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read(), dict(resp.headers)
    except urllib.error.HTTPError as e:
        # Read the error body so the handler can decode {"error": ..., "detail": ...}.
        try:
            body = e.read()
        except Exception:
            body = b""
        return e.code, body, dict(e.headers or {})
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise FfConnectionError(f"{method} {url}: {e}") from e


async def _request(
    base_url: str,
    method: str,
    path: str,
    *,
    json_body: dict[str, Any] | None = None,
    timeout: float = DEFAULT_TIMEOUT,
    token: str | None = None,
) -> tuple[bytes, dict[str, str]]:
    """Async request. Returns (body, headers) on 2xx, raises on error code.

    Token default falls back to env `FF_HOSTD_TOKEN`, so every call site
    inherits the shared secret without threading `token=` through each one.
    """
    url = f"{base_url}{path}"
    status, body, headers = await asyncio.to_thread(
        _http_call, method, url,
        json_body=json_body, timeout=timeout, token=token,
    )
    if 200 <= status < 300:
        return body, headers
    _raise_from_http(status, body, url=url)
    # _raise_from_http always raises; this line keeps type-checkers happy.
    raise FfConnectionError(f"{url}: unreachable code")


async def _request_json(
    base_url: str, method: str, path: str, **kw: Any
) -> dict[str, Any]:
    body, _ = await _request(base_url, method, path, **kw)
    if not body:
        return {}
    return json.loads(body.decode("utf-8", errors="replace"))


# ─── Adapter ────────────────────────────────────────────────────────────


class RemoteAdapter(PlatformAdapter):
    """Talk to a real robot via `ff_hostd` HTTP. Reports the downstream
    platform name (a2 / x2 / d1) from /health, so `session.adapter.platform_name`
    is meaningful even though the transport is uniform."""

    # Will be overwritten by connect() with the downstream platform name.
    platform_name = "remote"

    def __init__(self, **kwargs: object) -> None:
        super().__init__(**kwargs)  # type: ignore[arg-type]
        self._base_url: str = ""
        self._target: str = ""
        self._connected: bool = False
        self._capabilities: set[str] = set()
        self._downstream_target: str = ""
        # MVP token resolution: env FF_HOSTD_TOKEN (read inside _request).
        # Explicit kwarg through ff.connect() can land later; OPEN mode is
        # also fine when ff_hostd has no token set.
        # capability instances created lazily on connect()
        self._motion: RemoteMotion | None = None
        self._state: RemoteState | None = None
        self._audio: RemoteAudio | None = None
        self._vision: RemoteVision | None = None
        self._display: RemoteDisplay | None = None

    # --- Lifecycle ---------------------------------------------------

    async def connect(self, target: str) -> None:
        self._target = target
        self._base_url = _parse_remote_target(target)

        # /health is the ground truth for which capabilities ff_hostd exposes
        # for whichever robot it's sitting on. If this fails, we don't try to
        # pretend we have a session.
        try:
            health = await _request_json(
                self._base_url, "GET", "/health", timeout=DEFAULT_TIMEOUT
            )
        except FfConnectionError as e:
            raise FfConnectionError(
                f"ff_hostd at {self._base_url} unreachable: {e}"
            ) from e

        self._capabilities = set(health.get("capabilities", []) or [])
        self._downstream_target = str(health.get("target", "") or "")
        downstream_platform = str(health.get("platform", "") or "remote")
        # Tell users which robot we're really driving (e.g. "a2 via remote").
        # platform_name remains a class attr by default; override here.
        type(self).platform_name = "remote"  # keep class clean
        self.platform_name = f"{downstream_platform} via remote"  # type: ignore[misc]

        if "motion" in self._capabilities:
            self._motion = RemoteMotion(self)
        if "state" in self._capabilities:
            self._state = RemoteState(self)
        if "audio" in self._capabilities:
            self._audio = RemoteAudio(self)
        if "vision" in self._capabilities:
            self._vision = RemoteVision(self)
        if "display" in self._capabilities:
            self._display = RemoteDisplay(self)
        # navigation / arm / checkin not wired in MVP — these capability
        # surfaces stay None, so session.<x> raises CapabilityNotSupported.

        self._connected = True
        log.info(
            "RemoteAdapter connected to %s (target=%s caps=%s)",
            self._base_url, self._downstream_target,
            sorted(self._capabilities),
        )

    async def disconnect(self) -> None:
        self._connected = False
        # No persistent connection to close — urllib is one-shot.

    # --- Capability advertisement ------------------------------------

    def capabilities(self) -> set[str]:
        return set(self._capabilities) if self._connected else set()

    @property
    def motion(self) -> "RemoteMotion | None":
        return self._motion

    @property
    def state(self) -> "RemoteState | None":
        return self._state

    @property
    def audio(self) -> "RemoteAudio | None":
        return self._audio

    @property
    def vision(self) -> "RemoteVision | None":
        return self._vision

    @property
    def display(self) -> "RemoteDisplay | None":
        return self._display

    # --- Diagnostics -------------------------------------------------

    def diagnose(self) -> DiagnosticReport:
        # /health is a cheap probe; run it sync via the same urllib path.
        url = f"{self._base_url}/health"
        t0 = time.monotonic()
        try:
            status, body, _ = _http_call("GET", url, timeout=2.0)
            latency = (time.monotonic() - t0) * 1000.0
        except FfConnectionError as e:
            return DiagnosticReport(
                platform=self.platform_name,
                target=self._target or "<not-connected>",
                overall=HealthStatus.FAIL,
                checks=(
                    DiagnosticCheck(
                        name="ff_hostd reachable",
                        status=HealthStatus.FAIL,
                        detail=str(e),
                    ),
                ),
            )
        if status != 200:
            return DiagnosticReport(
                platform=self.platform_name,
                target=self._target or "<not-connected>",
                overall=HealthStatus.WARN,
                checks=(
                    DiagnosticCheck(
                        name="ff_hostd /health",
                        status=HealthStatus.WARN,
                        detail=f"HTTP {status}",
                        latency_ms=latency,
                    ),
                ),
            )
        info = json.loads(body.decode("utf-8", errors="replace"))
        checks = (
            DiagnosticCheck(
                name="ff_hostd reachable",
                status=HealthStatus.OK,
                detail=f"target={info.get('target')} platform={info.get('platform')}",
                latency_ms=latency,
            ),
            DiagnosticCheck(
                name="session state",
                status=(
                    HealthStatus.OK
                    if info.get("session_state") == "connected"
                    else HealthStatus.WARN
                ),
                detail=str(info.get("session_state")),
            ),
            DiagnosticCheck(
                name="estop",
                status=(
                    HealthStatus.WARN if info.get("estop_active") else HealthStatus.OK
                ),
                detail="active" if info.get("estop_active") else "clear",
            ),
        )
        overall = HealthStatus.OK
        for c in checks:
            if c.status is HealthStatus.FAIL:
                overall = HealthStatus.FAIL
                break
            if c.status is HealthStatus.WARN:
                overall = HealthStatus.WARN
        return DiagnosticReport(
            platform=self.platform_name,
            target=self._target,
            overall=overall,
            checks=checks,
        )

    # --- Emergency stop ----------------------------------------------

    async def e_stop(self, *, reason: str = "manual") -> None:
        log.warning(
            "RemoteAdapter.e_stop: reason=%s target=%s", reason, self._target
        )
        if not self._connected:
            return
        # Best-effort: tell ff_hostd to trip the real robot. The Session's
        # local estop already fired before us (Session.e_stop signature).
        try:
            await _request_json(
                self._base_url, "POST", "/e_stop",
                json_body={"reason": reason, "source": "ff_sdk-remote"},
                timeout=2.0,
            )
        except FfConnectionError as e:
            # ff_hostd unreachable on e_stop is bad but we don't want to mask
            # the local estop. Log and let the caller deal with it.
            log.error("RemoteAdapter.e_stop: ff_hostd POST /e_stop failed: %s", e)


# ─── URL parsing ────────────────────────────────────────────────────────


def _parse_remote_target(target: str) -> str:
    """`ff-host://host:port` → `http://host:port`. Validates the scheme."""
    parsed = urllib.parse.urlsplit(target)
    if parsed.scheme != REMOTE_SCHEME:
        raise FfConnectionError(
            f"RemoteAdapter requires {REMOTE_SCHEME}:// target, got {target!r}"
        )
    if not parsed.netloc:
        raise FfConnectionError(
            f"RemoteAdapter target missing host:port: {target!r}"
        )
    return f"http://{parsed.netloc}"


# ─── Capability implementations ─────────────────────────────────────────


class RemoteMotion(MotionCapability):
    """Motion proxy. Mirrors A2 router endpoints; the downstream adapter
    decides what's actually wired vs returns 501."""

    def __init__(self, adapter: RemoteAdapter) -> None:
        super().__init__(adapter)
        self._r: RemoteAdapter = adapter

    def _platform(self) -> str:
        return self._r._downstream_target.split("-", 1)[0].lower() or "a2"

    async def cmd_vel(
        self, linear: float = 0.0, angular: float = 0.0, lateral: float = 0.0
    ) -> MotionResult:
        return _to_motion_result(
            await _request_json(
                self._r._base_url, "POST",
                f"/{self._platform()}/motion/cmd_vel",
                json_body={"linear": linear, "angular": angular, "lateral": lateral},
            )
        )

    async def stop(self) -> MotionResult:
        return _to_motion_result(
            await _request_json(
                self._r._base_url, "POST", f"/{self._platform()}/motion/stop"
            )
        )

    async def stand(self) -> MotionResult:
        return _to_motion_result(
            await _request_json(
                self._r._base_url, "POST", f"/{self._platform()}/motion/stand"
            )
        )

    async def damping(self) -> MotionResult:
        return _to_motion_result(
            await _request_json(
                self._r._base_url, "POST", f"/{self._platform()}/motion/damping"
            )
        )

    async def do_preset(self, name: str) -> MotionResult:
        return _to_motion_result(
            await _request_json(
                self._r._base_url, "POST",
                f"/{self._platform()}/motion/do_preset",
                json_body={"name": name},
            )
        )


def _to_motion_result(d: dict[str, Any]) -> MotionResult:
    return MotionResult(
        success=bool(d.get("success", False)),
        message=str(d.get("message", "")),
        details={str(k): str(v) for k, v in (d.get("details") or {}).items()},
    )


class RemoteState(StateCapability):
    def __init__(self, adapter: RemoteAdapter) -> None:
        super().__init__(adapter)
        self._r: RemoteAdapter = adapter

    def _platform(self) -> str:
        return self._r._downstream_target.split("-", 1)[0].lower() or "a2"

    async def battery(self) -> BatteryState:
        d = await _request_json(
            self._r._base_url, "GET", f"/{self._platform()}/state/battery"
        )
        return BatteryState(
            percent=float(d.get("percent", 0.0)),
            voltage=(float(d["voltage"]) if d.get("voltage") is not None else None),
            is_charging=bool(d.get("is_charging", False)),
        )

    async def status(self) -> RobotStatus:
        d = await _request_json(
            self._r._base_url, "GET", f"/{self._platform()}/state/status"
        )
        raw = str(d.get("status", "unknown"))
        try:
            return RobotStatus(raw)
        except ValueError:
            return RobotStatus.UNKNOWN

    async def pose(self) -> Pose:
        d = await _request_json(
            self._r._base_url, "GET", f"/{self._platform()}/state/pose"
        )
        return Pose(
            x=float(d.get("x", 0.0)), y=float(d.get("y", 0.0)),
            z=float(d.get("z", 0.0)),
            roll=float(d.get("roll", 0.0)),
            pitch=float(d.get("pitch", 0.0)),
            yaw=float(d.get("yaw", 0.0)),
        )

    async def joint_states(self) -> JointStates:
        d = await _request_json(
            self._r._base_url, "GET", f"/{self._platform()}/state/joint_states"
        )
        return JointStates(
            names=tuple(d.get("names", []) or []),
            positions=tuple(float(x) for x in (d.get("positions", []) or [])),
            velocities=tuple(float(x) for x in (d.get("velocities", []) or [])),
            efforts=tuple(float(x) for x in (d.get("efforts", []) or [])),
        )


class RemoteAudio(AudioCapability):
    """Audio proxy. play_wav / stream_mic / volume map to downstream's
    405-CapabilityNotSupported on A2 today (no /api/play_wav). `say()` is
    the A2 extension — exposed here too for symmetry with A2Audio."""

    def __init__(self, adapter: RemoteAdapter) -> None:
        super().__init__(adapter)
        self._r: RemoteAdapter = adapter

    def _platform(self) -> str:
        return self._r._downstream_target.split("-", 1)[0].lower() or "a2"

    async def play_wav(self, wav_bytes: bytes) -> None:
        # No ff_hostd endpoint for raw WAV upload yet.
        raise CapabilityNotSupported(
            "RemoteAudio.play_wav not exposed by ff_hostd. Use audio.say(text)."
        )

    async def stream_mic(self, source: str = "default"):  # type: ignore[override]
        raise CapabilityNotSupported(
            "RemoteAudio.stream_mic not exposed by ff_hostd (HTTP only; no WS yet)."
        )

    async def volume(self, level: float) -> None:
        raise CapabilityNotSupported(
            "RemoteAudio.volume not exposed by ff_hostd."
        )

    async def say(
        self, text: str, *, engine: str = "openai", voice: str | None = None
    ) -> dict:
        body: dict[str, Any] = {"text": text, "engine": engine}
        if voice:
            body["voice"] = voice
        return await _request_json(
            self._r._base_url, "POST", f"/{self._platform()}/audio/say",
            json_body=body, timeout=TTS_TIMEOUT,
        )


class RemoteVision(VisionCapability):
    def __init__(self, adapter: RemoteAdapter) -> None:
        super().__init__(adapter)
        self._r: RemoteAdapter = adapter

    def _platform(self) -> str:
        return self._r._downstream_target.split("-", 1)[0].lower() or "a2"

    async def frame(self, source: str = "head_front") -> CameraFrame:
        qs = urllib.parse.urlencode({"source": source})
        body, headers = await _request(
            self._r._base_url, "GET",
            f"/{self._platform()}/vision/frame?{qs}",
        )
        # ff_hostd returns image/jpeg + X-Frame-Source / X-Frame-Encoding.
        return CameraFrame(
            timestamp=time.time(),
            data=body,
            encoding=str(headers.get("X-Frame-Encoding", "jpeg")).lower(),
            source=str(headers.get("X-Frame-Source", source)),
        )

    async def stream_camera(self, source: str = "default"):  # type: ignore[override]
        raise CapabilityNotSupported(
            "RemoteVision.stream_camera not exposed by ff_hostd (HTTP one-shot; "
            "use vision.frame() in a loop)."
        )

    async def list_cams(self) -> tuple[str, ...]:
        d = await _request_json(
            self._r._base_url, "GET", f"/{self._platform()}/vision/cams"
        )
        return tuple(d.get("cams", []) or [])

    async def capture_to_album(self) -> dict:
        return await _request_json(
            self._r._base_url, "POST", f"/{self._platform()}/vision/capture"
        )


class RemoteDisplay(DisplayCapability):
    def __init__(self, adapter: RemoteAdapter) -> None:
        super().__init__(adapter)
        self._r: RemoteAdapter = adapter

    def _platform(self) -> str:
        return self._r._downstream_target.split("-", 1)[0].lower() or "a2"

    async def show_expression(self, preset: str) -> None:
        await _request_json(
            self._r._base_url, "POST",
            f"/{self._platform()}/display/expression",
            json_body={"preset": preset},
        )

    async def list_expressions(self) -> tuple[str, ...]:
        d = await _request_json(
            self._r._base_url, "GET", f"/{self._platform()}/display/expressions"
        )
        return tuple(d.get("expressions", []) or [])

    async def show_text(self, text: str) -> None:
        # ff_hostd A2 router does not expose /display/text (A2Display.show_text
        # itself raises CapabilityNotSupported). Mirror that without a round-trip.
        raise CapabilityNotSupported(
            "RemoteDisplay.show_text not exposed by ff_hostd."
        )

    async def set_led(
        self, *, color: str = "off", pattern: str = "solid"
    ) -> None:
        raise CapabilityNotSupported(
            "RemoteDisplay.set_led not exposed by ff_hostd."
        )
