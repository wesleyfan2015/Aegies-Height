"""Platform layer — vendor-hiding adapters.

Adapter modules are imported **lazily** (only when their target is actually
requested), so a per-platform / per-robot trimmed build that ships only one
platform's adapter still imports cleanly — `import ff_sdk.platforms` never
pulls in adapters that were left out of the package. A missing platform
surfaces as a clear `ConfigError`, not an ImportError at import time.

Per PLAN §4.2, vendor SDK detail lives only under these adapters + their
`internal/oem/*` modules and never surfaces in public API types.
"""
from __future__ import annotations

import importlib

from ff_sdk.core.exceptions import ConfigError
from ff_sdk.platforms.base import DiagnosticReport, PlatformAdapter

__all__ = [
    "PlatformAdapter",
    "DiagnosticReport",
    "A2Adapter",
    "X2Adapter",
    "D1Adapter",
    "MujocoAdapter",
    "RemoteAdapter",
    "NaviAdapter",
    "resolve_adapter",
]

# Platform key → (module, adapter class name). The module is imported lazily.
_ADAPTERS: dict[str, tuple[str, str]] = {
    "a2": ("ff_sdk.platforms.a2", "A2Adapter"),
    "x2": ("ff_sdk.platforms.x2", "X2Adapter"),
    "d1": ("ff_sdk.platforms.d1", "D1Adapter"),
    "navi": ("ff_sdk.platforms.navi", "NaviAdapter"),
    "mujoco": ("ff_sdk.platforms.mujoco", "MujocoAdapter"),
    "remote": ("ff_sdk.platforms.remote", "RemoteAdapter"),
}
_CLASS_TO_KEY: dict[str, str] = {cls: key for key, (_mod, cls) in _ADAPTERS.items()}


def _load(key: str) -> type[PlatformAdapter]:
    mod_name, cls_name = _ADAPTERS[key]
    try:
        mod = importlib.import_module(mod_name)
    except ImportError as e:
        raise ConfigError(
            f"platform '{key}' is not included in this ff_sdk build. "
            f"This looks like a per-platform package that ships only one "
            f"robot model's adapter — install the build matching this robot."
        ) from e
    return getattr(mod, cls_name)


def resolve_adapter(target: str) -> type[PlatformAdapter]:
    """Pick the adapter class for a target URI (lazy import).

    Target forms:
        A2-<sn>              Futurist humanoid (internal code A2)
        X2-<sn>              Master humanoid (internal code X2)
        D1-<sn>              Aegis quadruped (internal code D1)
        NV-<sn>              Navi quadruped, Dev variant (default)
        NV-Mini-<sn>         Navi quadruped, Mini (consumer) variant
        mujoco://<a2|d1>     physics simulation
        ff-host://host:port  any robot via ff_hostd HTTP daemon
    """
    t = target.strip()
    lower = t.lower()
    if lower.startswith("ff-host://"):
        return _load("remote")
    upper = t.upper()
    if upper.startswith("A2-") or upper == "A2":
        return _load("a2")
    if upper.startswith("X2-") or upper == "X2":
        return _load("x2")
    if upper.startswith("D1-") or upper == "D1":
        return _load("d1")
    if upper.startswith("NV-") or upper.startswith("NAVI-") or upper in ("NV", "NAVI"):
        return _load("navi")
    if lower.startswith("mujoco://"):
        return _load("mujoco")
    raise ConfigError(f"no adapter available for target {target!r}")


def __getattr__(name: str) -> object:
    """PEP 562 lazy attribute access — `from ff_sdk.platforms import D1Adapter`
    works when that adapter is in the build, and raises cleanly when it isn't."""
    if name in _CLASS_TO_KEY:
        return _load(_CLASS_TO_KEY[name])
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
